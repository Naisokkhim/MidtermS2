import javax.swing.*;
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LockerApp app = new LockerApp();
            app.setVisible(true);
        });
    }
}